r = 100; // we can adjust the speed here
adjustJank = 4; // this just adds to the distance animated to smooth out the seam

// Set up for what appears to be an seamless stream
$(window).on('load', function(){
  $(".slider-wrapper p").each(function () {
    var obj = $(this);
    var d = $(this).width();
    obj.clone().appendTo(obj.parent());
    obj.clone().appendTo(obj.parent()); // Duplicating for infinite scroll
    obj.parent().parent().width(d);

    var t = d / r; //Calculating the duration or time of animation

    // GSAP animation
    gsap.to(
      obj.parent(),
      t, // our calculated time
      {
        x: "-" + (d + adjustJank),
        rotation: 0.01,
        ease: Linear.easeNone,
        repeat: -1,
      }
    );
  });
})
